
# AWS Node.js Lambda to Lambda Execution

This project demonstrates how to invoke one AWS Lambda function from another using Node.js and the AWS SDK.

## Setup Instructions

### Prerequisites
1. AWS CLI configured with appropriate permissions.
2. Node.js installed on your local machine.

### Steps

1. **Install Dependencies**  
   Each Lambda function requires the AWS SDK. The `aws-sdk` comes preinstalled in AWS Lambda environments, but locally you may need to install it for testing. Run this in each Lambda's directory:
   ```bash
   npm install
   ```

2. **Deploy the Lambda Functions**

   - First, create two Lambda functions in AWS:
     - Lambda 1: This Lambda will invoke Lambda 2.
     - Lambda 2: This Lambda will process the request and return a response.
   
   - Upload the code for `lambda1` and `lambda2` to their respective Lambda functions using the AWS Lambda console or AWS CLI.

3. **Set Permissions**
   Lambda 1 needs permission to invoke Lambda 2. You can attach an AWS Lambda policy using the AWS CLI:
   ```bash
   aws lambda add-permission --function-name <Lambda2Name> --statement-id <statementId> --action lambda:InvokeFunction --principal lambda.amazonaws.com
   ```

4. **Test the Setup**
   Trigger Lambda 1 using a test event from the AWS Lambda console. It should invoke Lambda 2 and log the result.

## Code Explanation

### Lambda 1 - Invoker
This function triggers Lambda 2 using the AWS SDK's `invoke` method.

```javascript
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

exports.handler = async (event) => {
    const params = {
        FunctionName: 'Lambda2FunctionName', // Replace with actual Lambda 2 name
        InvocationType: 'RequestResponse',
        Payload: JSON.stringify({ key1: 'value1' }) // Add payload if necessary
    };
    
    try {
        const response = await lambda.invoke(params).promise();
        console.log('Lambda 2 response:', response);
        return response;
    } catch (error) {
        console.error('Error invoking Lambda 2:', error);
        throw error;
    }
};
```

### Lambda 2 - Responder
This function is invoked by Lambda 1 and returns a response.

```javascript
exports.handler = async (event) => {
    console.log('Lambda 2 invoked with event:', event);
    return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Lambda 2 executed successfully!' })
    };
};
```

## Local Testing

You can run Lambda 1 locally using the following command after installing dependencies:
```bash
node index.js
```
Ensure you have the correct AWS credentials configured locally for testing.
