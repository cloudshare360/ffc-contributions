
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

exports.handler = async (event) => {
    const params = {
        FunctionName: 'Lambda2FunctionName', // Replace with actual Lambda 2 name
        InvocationType: 'RequestResponse',
        Payload: JSON.stringify({ key1: 'value1' }) // Add payload if necessary
    };
    
    try {
        const response = await lambda.invoke(params).promise();
        console.log('Lambda 2 response:', response);
        return response;
    } catch (error) {
        console.error('Error invoking Lambda 2:', error);
        throw error;
    }
};
