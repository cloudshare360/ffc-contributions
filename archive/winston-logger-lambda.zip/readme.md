
# Winston Logger for AWS Lambda

This project demonstrates how to use the Winston logging library with different logging levels (info, debug, warn, error) inside an AWS Lambda function.

## Prerequisites

- Node.js installed locally
- AWS SDK installed globally or locally in your workspace
- Access to an AWS account to deploy the Lambda function

## Project Structure

- **index.js**: The Lambda function which integrates Winston logging.
- **logger.js**: Winston configuration for logging different levels.
- **package.json**: Dependencies, including Winston and AWS SDK.

## Installation

1. Install the dependencies by running the following command inside the project directory:

```bash
npm install
```

2. To run the Lambda function locally (you can simulate the event by passing an event object):

```bash
node index.js
```

## Environment Variables

You can set the logging level by providing a `LOG_LEVEL` environment variable. For example:

```bash
export LOG_LEVEL=debug
```

By default, it is set to `info`.

## AWS Lambda Integration

To integrate this project into an existing AWS Lambda workspace:

1. Zip the contents of the directory (excluding `node_modules` if you deploy Lambda via the AWS console):
   
```bash
zip -r winston-logger-lambda.zip .
```

2. Upload the `winston-logger-lambda.zip` to your Lambda function via the AWS Console or use the AWS CLI.

If you're using SAM or any deployment automation tool, just add this project to your workspace, and it will automatically install dependencies and deploy the Lambda.

## Logging Levels

- **info**: General operational information.
- **debug**: Detailed information useful for debugging.
- **warn**: Non-critical issues that need attention.
- **error**: Critical issues that cause function failure.
