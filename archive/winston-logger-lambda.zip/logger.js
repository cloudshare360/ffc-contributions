
const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',  // Use environment variable to set log level, default to 'info'
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()  // Log output format as JSON
  ),
  transports: [
    new winston.transports.Console()  // Log to console
  ],
});

module.exports = logger;
