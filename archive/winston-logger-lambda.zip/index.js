
const logger = require('./logger');

exports.handler = async (event) => {
  try {
    // Log incoming event
    logger.info('Lambda function started', { event });

    // Simulate different log levels
    logger.debug('This is a debug message');
    logger.warn('This is a warning message');
    logger.error('This is an error message');

    const result = { message: 'Lambda executed successfully!' };
    logger.info('Lambda execution result', { result });

    return {
      statusCode: 200,
      body: JSON.stringify(result),
    };

  } catch (error) {
    logger.error('An error occurred', { error });
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    };
  }
};
