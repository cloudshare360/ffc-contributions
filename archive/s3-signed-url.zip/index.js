// index.js
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const bucketName = 'your-bucket-name';  // Replace with your bucket name
const objectKey = 'your-file-key';      // Replace with the file key (file name)

async function generateSignedUrl() {
    const params = {
        Bucket: bucketName,
        Key: objectKey,
        Expires: 60 * 5 // URL valid for 5 minutes
    };

    try {
        const signedUrl = await s3.getSignedUrlPromise('getObject', params);
        console.log('Signed URL:', signedUrl);
        return signedUrl;
    } catch (error) {
        console.error('Error generating signed URL:', error.message);
    }
}

// Call the function
generateSignedUrl();
