
# AWS Lambda Logging with Winston

This project demonstrates how to use the Winston logging library in a Node.js AWS Lambda function.

## Setup Instructions

1. Clone the repository or download the ZIP file.
2. Install the required dependencies:
   ```bash
   npm install
   ```
3. Run the code locally to test logging:
   ```bash
   node index.js
   ```

### AWS Lambda Integration
To integrate this with AWS Lambda:

1. Update your Lambda function code to include the Winston logger.
2. Ensure that `winston` is included in your `package.json` file.
3. Deploy the Lambda function using your preferred method (AWS SAM, Serverless Framework, or manual upload).

## Logging Levels

This logger has been configured to handle the following log levels:
- **info**: General information.
- **debug**: Debugging information.
- **error**: Error messages.

## Code Example

Below is an example of how to use the logger in a Node.js AWS Lambda function:

```javascript
const logger = require('./logger');

exports.handler = async (event) => {
    logger.info('Lambda function started');
    try {
        // Your code logic here
        logger.debug('Debugging information');
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Success' })
        };
    } catch (error) {
        logger.error('An error occurred:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error' })
        };
    }
};
```
