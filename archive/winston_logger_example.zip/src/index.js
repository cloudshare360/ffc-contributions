
const logger = require('./logger');

async function main() {
    logger.info('Starting the application...');
    
    try {
        logger.debug('This is a debug message');
        // Simulate some logic
        const result = { message: 'Success' };
        logger.info('Result:', result);
    } catch (error) {
        logger.error('An error occurred:', error);
    }

    logger.info('Application finished');
}

main();
